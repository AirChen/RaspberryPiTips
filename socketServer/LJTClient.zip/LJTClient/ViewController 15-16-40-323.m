//
//  ViewController.m
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import "ViewController.h"
#import "GCDAsyncSocket.h"

@interface ViewController ()<GCDAsyncSocketDelegate>

@property(nonatomic, strong)GCDAsyncSocket *socket;

@end

@implementation ViewController

- (GCDAsyncSocket *)socket
{
    if (!_socket) {
        NSLog(@"inital!");
        
        _socket = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    }
    return _socket;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

- (IBAction)openConnect:(id)sender {
    NSString *host = @"127.0.0.1";
    int port = 8001;
    
    NSError *error = nil;
    [self.socket connectToHost:host onPort:port error:&error];
    
    [self.socket readDataWithTimeout:-1 tag:200];
}

- (IBAction)sendMsg:(id)sender {
    
    [self.socket writeData:[@"Hello" dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:101];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.socket writeData:[@"1" dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:101];

}

- (IBAction)closeConnect:(id)sender {
    
    [self.socket disconnect];
    
    self.socket = nil;
}

#pragma mark - GCDAsyncSocketDelegate
- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port
{
    NSLog(@"host:%@",host);
}

- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    NSLog(@"readData %@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
    
    [self.socket readDataWithTimeout:-1 tag:200];
}

@end
