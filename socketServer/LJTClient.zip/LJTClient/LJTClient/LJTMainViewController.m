//
//  LJTMainViewController.m
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import "LJTMainViewController.h"
#import "LJTItemsListView.h"
#import "GCDAsyncSocket.h"
#import "UIAlertController+Blocks.h"

#import "LJTPhotoViewController.h"

@interface LJTMainViewController ()<GCDAsyncSocketDelegate>

@property(nonatomic, strong)LJTItemsListView *listView;
@property(nonatomic, strong)GCDAsyncSocket *socket;
@property (nonatomic, strong)NSMutableArray *dataArray;

@property (nonatomic, strong)UIBarButtonItem *serverButtonItem;
@property (nonatomic, assign)BOOL serverStatus;

@end

@implementation LJTMainViewController

#pragma mark - lazy load
- (LJTItemsListView *)listView
{
    if (!_listView) {
        
        _listView = [[LJTItemsListView alloc] initWithFrame:self.view.bounds];
        
        __weak LJTMainViewController *weakSelf = self;
        _listView.clickEvent = ^(NSString *uuid){
            LJTPhotoViewController *photoViewController = [[LJTPhotoViewController alloc] init];
            photoViewController.uuidString = [uuid copy];
            
            [weakSelf.navigationController pushViewController:photoViewController animated:YES];
        };
        
    }
    return _listView;
}

- (GCDAsyncSocket *)socket
{
    if (!_socket) {
        NSLog(@"inital!");
        
        _socket = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    }
    return _socket;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

#pragma mark - life methods
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"Demo";
    
    UIBarButtonItem *sendButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Send" style:UIBarButtonItemStylePlain target:self action:@selector(sendMsg)];
    self.navigationItem.leftBarButtonItem = sendButtonItem;
    
    UIBarButtonItem *serverButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Connect" style:UIBarButtonItemStylePlain target:self action:@selector(dealServerStatus)];
    self.navigationItem.rightBarButtonItem = serverButtonItem;
    self.serverButtonItem = serverButtonItem;
    self.serverStatus = NO;
    
    NSMutableArray *itemsArray = [NSMutableArray array];
    for (NSUInteger i = 0; i < 20; i ++) {
        [itemsArray addObject:[NSString stringWithFormat:@"item[%lu]",(unsigned long)i]];
    }
    
    self.listView.itemArray = itemsArray;
    
    [self.view addSubview:self.listView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealServerStatus
{
    if (self.serverStatus) {
        [self closeConnect];
        [self.serverButtonItem setTitle:@"Connect"];
        self.serverStatus = NO;
    }else{
        [self openConnect];
    }
}

- (void)openConnect {
    NSString *host = @"127.0.0.1";
    int port = 8001;
    
    NSError *error = nil;
    [self.socket connectToHost:host onPort:port error:&error];
    
    [self.socket readDataWithTimeout:-1 tag:200];
}

- (void)sendMsg {
    
    [self.socket writeData:[@"1" dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:101];
}


- (void)closeConnect {
    [self.socket disconnect];
    
    self.socket = nil;
}

#pragma mark - GCDAsyncSocketDelegate
- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port
{
    NSLog(@"host:%@",host);
    
    [UIAlertController showAlertInViewController:self withTitle:@"通知" message:@"与服务器已连接上！" cancelButtonTitle:@"确定" destructiveButtonTitle:@"关闭" otherButtonTitles:nil tapBlock:^(UIAlertController * _Nonnull controller, UIAlertAction * _Nonnull action, NSInteger buttonIndex) {
        [self.serverButtonItem setTitle:@"DisConnect"];
        self.serverStatus = YES;
    }];
}

- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    NSLog(@"readData %@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
    
    NSString *msg = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    //alter
    [UIAlertController showAlertInViewController:self withTitle:@"通知" message:@"发现监测区域有人口变化" cancelButtonTitle:@"确定" destructiveButtonTitle:@"关闭" otherButtonTitles:nil tapBlock:^(UIAlertController * _Nonnull controller, UIAlertAction * _Nonnull action, NSInteger buttonIndex) {
        //add item
        [self.dataArray addObject:msg];
        
       //reload listView
        self.listView.itemArray = self.dataArray;
        [self.listView reloadData];
    }];
    
    [self.socket readDataWithTimeout:-1 tag:200];
}


@end
