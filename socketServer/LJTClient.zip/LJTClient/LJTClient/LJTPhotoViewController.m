//
//  LJTPhotoViewController.m
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import "LJTPhotoViewController.h"
#import "LJTZoomView.h"

@interface LJTPhotoViewController ()<NSURLConnectionDataDelegate>

@property(nonatomic, strong)LJTZoomView *zoomView;
@property (nonatomic, strong)NSMutableData *imgData;

@end

@implementation LJTPhotoViewController

- (LJTZoomView *)zoomView
{
    if (!_zoomView) {
        _zoomView = [[LJTZoomView alloc] initWithFrame:self.view.bounds];
    }
    return _zoomView;
}

- (NSMutableData *)imgData
{
    if (!_imgData) {
        _imgData = [NSMutableData data];
    }
    return _imgData;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor orangeColor];
    
    //net -> image
    [self getImageFromHttp];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)getImageFromHttp {
    
    NSString *str = [NSString stringWithFormat:@"http://api.heclouds.com/bindata/%@",self.uuidString];
    str = [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    NSURL *url = [NSURL URLWithString:str];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20];
    [request setValue:@"Y8gdH8Mim1wCfgHBEIK2TRQWE9o=" forHTTPHeaderField:@"api-key"];

    NSURLConnection *connect = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [connect start];
}

#pragma mark - NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.imgData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"%@",self.imgData);
    
    self.zoomView.image = [UIImage imageWithData:self.imgData];
    self.zoomView.maximumZoomScale = 2.0;
    self.zoomView.contentMode = UIViewContentModeScaleAspectFit;
    [self.view addSubview:self.zoomView];
    
    self.imgData = nil;
}

@end
