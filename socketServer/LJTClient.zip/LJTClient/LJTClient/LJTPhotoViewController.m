//
//  LJTPhotoViewController.m
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import "LJTPhotoViewController.h"
#import "LJTZoomView.h"

@interface LJTPhotoViewController ()

@property(nonatomic, strong)LJTZoomView *zoomView;

@end

@implementation LJTPhotoViewController

- (LJTZoomView *)zoomView
{
    if (!_zoomView) {
        _zoomView = [[LJTZoomView alloc] initWithFrame:self.view.bounds];
    }
    return _zoomView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor orangeColor];
    
    //net -> image
    
    self.zoomView.image = [UIImage imageNamed:@"Unknown"];
    self.zoomView.maximumZoomScale = 2.0;
    self.zoomView.contentMode = UIViewContentModeScaleAspectFit;
    [self.view addSubview:self.zoomView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
