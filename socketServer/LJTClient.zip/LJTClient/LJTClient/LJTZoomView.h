//
//  LJTZoomView.h
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LJTZoomView : UIView

@property (nonatomic, strong)UIImage *image;

@property (nonatomic, assign)CGFloat maximumZoomScale;

@end
