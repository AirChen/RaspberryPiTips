//
//  LJTItemsListView.m
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import "LJTItemsListView.h"

@interface LJTItemsListView()<UITableViewDelegate, UITableViewDataSource>

@end

@implementation LJTItemsListView

- (NSArray *)itemArray
{
    if (!_itemArray) {
        _itemArray = [NSArray array];
    }
    return _itemArray;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self prepareOrigan];
    }
    return self;
}

- (void)prepareOrigan
{
    self.delegate = self;
    self.dataSource = self;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.itemArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.textLabel.text = self.itemArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *uuid = self.itemArray[indexPath.row]; //some........deal
    
    if (self.clickEvent) {
        self.clickEvent(uuid);
    }
}

@end
