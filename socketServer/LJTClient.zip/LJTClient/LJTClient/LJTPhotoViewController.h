//
//  LJTPhotoViewController.h
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LJTPhotoViewController : UIViewController

@property (nonatomic, copy)NSString *uuidString;

@end
