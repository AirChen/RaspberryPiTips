//
//  LJTItemsListView.h
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^ItemListClick)(NSString *url);

@interface LJTItemsListView : UITableView

@property (nonatomic, copy)NSArray *itemArray;
@property (nonatomic, copy)ItemListClick clickEvent;

@end
