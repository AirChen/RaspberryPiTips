//
//  main.m
//  LJTClient
//
//  Created by AirChen on 2017/2/13.
//  Copyright © 2017年 AirChen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
